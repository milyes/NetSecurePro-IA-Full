#!/bin/bash
echo '🔓 Veuillez entrer le mot-clé de déverrouillage IA :'
read key
if [ "$key" == "unlock_ai" ]; then echo '✅ Accès accordé à la plateforme IA.'; else echo '❌ Accès refusé.'; fi