#!/bin/bash
echo 'Surveillance IA activée...'