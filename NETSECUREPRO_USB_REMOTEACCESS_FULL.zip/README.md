# NetSecurePro_USB_RemoteAccess

## Description
Ce système détecte automatiquement une clé USB connectée et lance un accès distant IA via interface WebView + tunnel Cloudflare.

## Exécution
```bash
chmod +x *.sh
bash unlock.sh
```

## Auteur
**Zoubirou Mohammed Ilyes**  
ORCID: https://orcid.org/0009-0007-7571-3178
